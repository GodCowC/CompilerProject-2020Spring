#include "../run2.h"

void grad_case8(float (&dB)[32], float (&dA)[2][16]) {}
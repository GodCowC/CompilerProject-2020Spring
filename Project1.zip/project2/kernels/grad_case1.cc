#include "../run2.h"

void grad_case1(float (&B)[4][16], float (&dC)[4][16], float (&A)[4][16]) {}
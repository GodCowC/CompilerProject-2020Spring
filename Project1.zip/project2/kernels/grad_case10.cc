#include "../run2.h"

void grad_case10(float (&dA)[8][8], float (&dB)[10][8]) {}
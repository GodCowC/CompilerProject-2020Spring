#include "../run2.h"

void grad_case9(float (&dB)[4][6], float (&dA)[4]) {}
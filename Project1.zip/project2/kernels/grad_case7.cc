#include "../run2.h"

void grad_case7(float (&dB)[16][32], float (&dA)[32][16]) {}